/**
 * SpaceHub — Méthodes appelées mais jamais définies
 * ================================================
 *
 * Deux défauts de la même famille, trouvés à deux endroits sans rapport :
 *
 *   - `SpatialNavigation.popFocus` appelait `this._isElementVisible?.(…)`.
 *     La méthode n'existait nulle part. L'optionnel `?.` renvoyait `undefined`,
 *     et `undefined !== false` vaut `true` : le test de visibilité était donc
 *     TOUJOURS satisfait, silencieusement, depuis toujours ;
 *   - la commande « Surprenez-moi ! » appelait `this._getDefaultCatalog()`.
 *     La méthode n'existait pas davantage — mais sans `?.`, celle-là levait
 *     une TypeError. La commande figurait dans la palette et n'avait jamais
 *     rien lancé.
 *
 * Les deux sont invisibles à l'exécution normale : l'un ne lève pas, l'autre
 * n'est déclenché que par une action rare. Aucun test ne les couvrait, et
 * aucun n'aurait naturellement pensé à les couvrir.
 *
 * Ce contrôle lit chaque classe, relève les `this._xxx(` qu'elle appelle, et
 * vérifie que le nom est défini quelque part dans le fichier — méthode,
 * champ, ou affectation. Il ne remonte pas les chaînes d'héritage : les
 * classes de ce dépôt n'en ont pas.
 */

import fs from 'node:fs';
import path from 'node:path';

const ROOTS = ['core', 'ui', 'jellyfin', 'integrations', 'plugins'];

function walk(dir, out = []) {
    if (!fs.existsSync(dir)) return out;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) walk(p, out);
        else if (e.name.endsWith('.js')) out.push(p);
    }
    return out;
}

const fantomes = [];
let appelsVerifies = 0;
let fichiers = 0;

for (const f of ROOTS.flatMap(r => walk(r))) {
    const rel = f.split(path.sep).join('/');
    const brut = fs.readFileSync(f, 'utf8');
    // Les commentaires citent volontiers le nom d'une méthode disparue — c'est
    // même le cas de ceux qui EXPLIQUENT sa disparition. On les neutralise en
    // conservant les sauts de ligne, pour que les numéros restent justes.
    const src = brut
        .replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, ' '))
        .replace(/(^|[^:])\/\/[^\n]*/g, (m, p1) => p1 + ' '.repeat(m.length - p1.length));
    if (!/\bclass\s+\w/.test(src)) continue;
    if (/\bextends\s+\w/.test(src)) continue;   // héritage : hors périmètre
    fichiers++;

    // Tout ce que le fichier DÉFINIT sur l'instance, sous n'importe quelle forme.
    const definis = new Set();
    for (const m of src.matchAll(/^\s{0,8}(?:async\s+|static\s+|\*\s*)*(_\w+)\s*\(/gm)) definis.add(m[1]);
    for (const m of src.matchAll(/this\.(_\w+)\s*=/g)) definis.add(m[1]);
    for (const m of src.matchAll(/^\s{0,8}(_\w+)\s*=/gm)) definis.add(m[1]);
    // Objets littéraux : `{ _machin() {} }` ou `{ _machin: () => {} }`
    for (const m of src.matchAll(/(_\w+)\s*:\s*(?:async\s*)?(?:function|\()/g)) definis.add(m[1]);

    for (const m of src.matchAll(/this\.(_\w+)\s*\??\.?\s*\(/g)) {
        appelsVerifies++;
        const nom = m[1];
        if (definis.has(nom)) continue;
        fantomes.push({ rel, ligne: src.slice(0, m.index).split('\n').length, nom });
    }
}

if (fantomes.length) {
    console.error(`Méthodes fantômes : ${fantomes.length} appel(s) vers une méthode jamais définie.\n`);
    for (const g of fantomes) console.error(`  x ${g.rel}:${g.ligne} — this.${g.nom}(…)`);
    console.error('\nUn appel `this._xxx?.(…)` ne lève pas : il renvoie undefined, et le');
    console.error('code continue avec une valeur fausse. Sans ce contrôle, le défaut est');
    console.error('invisible. Définissez la méthode, ou retirez l\'appel.');
    process.exit(1);
}

console.log(`Méthodes fantômes : ${appelsVerifies} appel(s) vérifié(s) dans ${fichiers} classe(s).`);
console.log('Toute méthode appelée sur `this` est définie dans son fichier.');
